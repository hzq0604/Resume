package com.resume.model;
/**
 * ��������ʵ����Work_info
 * ��Ӧ���ݿ��е�work_info��
 *
 */
public class Work_info {
	private int Workid;//����
	private String Company;//��ҵ��
	private String Position;//ְλ
	private String Duty;//ְ��
	private String Departure;//��ְʱ��
	private int Userid;//�û�
	public int getWorkid() {
		return Workid;
	}
	public void setWorkid(int workid) {
		Workid = workid;
	}
	public String getCompany() {
		return Company;
	}
	public void setCompany(String company) {
		Company = company;
	}
	public String getPosition() {
		return Position;
	}
	public void setPosition(String position) {
		Position = position;
	}
	public String getDuty() {
		return Duty;
	}
	public void setDuty(String duty) {
		Duty = duty;
	}
	public String getDeparture() {
		return Departure;
	}
	public void setDeparture(String departure) {
		Departure = departure;
	}
	public int getUserid() {
		return Userid;
	}
	public void setUserid(int userid) {
		Userid = userid;
	}
	
}
