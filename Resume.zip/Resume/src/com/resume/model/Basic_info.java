package com.resume.model;
/**
 * Basic_infoʵ����
 * ��Ӧ���ݿ��е�basic_info��
 * �����Ļ�����Ϣʵ����
 */
public class Basic_info {
	
	private int ID;//������ID
	private String Name;//����
	private String Gender;//�Ա�
	private int Age;//����
	private String Address;//��ַ
	private String Email;//�ʼ�
	private String Tel;//�绰
	private String School;//��ҵԺУ
	private String Introduce;//���ҽ���
	private int UserId;//�û�ID
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	public int getAge() {
		return Age;
	}
	public void setAge(int age) {
		Age = age;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getTel() {
		return Tel;
	}
	public void setTel(String tel) {
		Tel = tel;
	}
	public String getSchool() {
		return School;
	}
	public void setSchool(String school) {
		School = school;
	}
	public String getIntroduce() {
		return Introduce;
	}
	public void setIntroduce(String introduce) {
		Introduce = introduce;
	}
	public int getUserId() {
		return UserId;
	}
	public void setUserId(int userId) {
		this.UserId = userId;
	}
	
	
}
