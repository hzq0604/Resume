package com.resume.model;
/**
 * ������Ϣʵ����Educational_info
 * ��Ӧ���ݿ��е�educational_info��
 *
 */
public class Educational_info {
	private int Eduid;//����
	private String School;//ѧУ
	private String Major;//רҵ
	private String Education;//ѧ��
	private String Graduation;//��ҵʱ��
	private int Userid;//�û�
	public int getEduid() {
		return Eduid;
	}
	public void setEduid(int eduid) {
		Eduid = eduid;
	}
	public String getSchool() {
		return School;
	}
	public void setSchool(String school) {
		School = school;
	}
	public String getMajor() {
		return Major;
	}
	public void setMajor(String major) {
		Major = major;
	}
	public String getEducation() {
		return Education;
	}
	public void setEducation(String education) {
		Education = education;
	}
	public String getGraduation() {
		return Graduation;
	}
	public void setGraduation(String graduation) {
		Graduation = graduation;
	}
	public int getUserid() {
		return Userid;
	}
	public void setUserid(int userid) {
		Userid = userid;
	}
	@Override
	public String toString() {
		return "Educational_info [School=" + School + "]";
	}
	
	
	
	
}
