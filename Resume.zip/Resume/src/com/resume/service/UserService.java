package com.resume.service;
import com.resume.model.User_info;

public interface UserService {
		User_info login(String Name);

}
