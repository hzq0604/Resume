package com.resume.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.resume.mapper.UserMapper;
import com.resume.model.User_info;

/**
 * ����ǰ��ע��Ϊһ�� Spring �� bean
 **/
@Service
@Transactional
public class UserServiceImpl implements UserService{
	//�Զ�ɨ��ע��
	@Autowired
	public UserMapper usermapper;
	//��д����
	@Override
	public User_info login(String Name) {
		return usermapper.login(Name);
	}


}
